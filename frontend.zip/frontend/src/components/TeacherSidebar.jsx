import { NavLink, useNavigate } from "react-router-dom";
import { FiHome, FiBook, FiCalendar, FiSettings, FiLogOut } from "react-icons/fi";
import "../styles/TeacherSidebar.css";

const TeacherSidebar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/");
  };

  return (
    <div className="teacher-sidebar">
      <div className="logo">
        <h2>Enlight<span className="dot">.</span></h2>
      </div>
      <nav className="menu">
        <NavLink to="/dashboard" className="menu-item">
          <FiHome className="icon" /> Главная
        </NavLink>
        <NavLink to="/teacher/courses" className="menu-item">
          <FiBook className="icon" /> Мои курсы
        </NavLink>
        <NavLink to="/teacher/events" className="menu-item">
          <FiCalendar className="icon" /> Мероприятия
        </NavLink>
        <NavLink to="/teacher/settings" className="menu-item">
          <FiSettings className="icon" /> Настройки
        </NavLink>
      </nav>
      <div className="logout">
        <button className="menu-item logout-btn" onClick={handleLogout}>
          <FiLogOut className="icon" /> Выйти
        </button>
      </div>
    </div>
  );
};

export default TeacherSidebar;
